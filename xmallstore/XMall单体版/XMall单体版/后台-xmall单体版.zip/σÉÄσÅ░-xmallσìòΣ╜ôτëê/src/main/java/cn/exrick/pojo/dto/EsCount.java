package cn.exrick.pojo.dto;

import java.io.Serializable;

/**
 * @author Exrickx
 */
public class EsCount implements Serializable {

    private Integer count;

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }
}
