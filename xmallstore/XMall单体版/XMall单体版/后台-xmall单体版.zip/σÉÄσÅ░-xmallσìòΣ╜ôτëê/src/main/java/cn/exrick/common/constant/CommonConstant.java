package cn.exrick.common.constant;


/**
 * 常量
 * @author Exrickx
 */
public interface CommonConstant {

    /**
     * 限流标识
     */
    String LIMIT_ALL="XMALL_LIMIT_ALL";
}
