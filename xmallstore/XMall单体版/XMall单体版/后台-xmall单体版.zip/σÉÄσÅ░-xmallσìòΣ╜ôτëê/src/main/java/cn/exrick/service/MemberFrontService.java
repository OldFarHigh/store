package cn.exrick.service;

public interface MemberFrontService {

    String imageUpload(Long userId, String token, String imgData);
}
